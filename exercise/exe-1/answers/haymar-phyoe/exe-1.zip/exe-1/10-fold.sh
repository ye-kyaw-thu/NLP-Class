#!/bin/bash

size=$(wc -l < $1)
echo $size
one_tenth=$((size/10))
echo $one_tenth

for i in {0..9}
do
  mkdir -p ~/NLP_Class/exe-1/Experiment$((i+1))
  cat $1 | sed -n $((i*one_tenth+1)),$(((i+1)*one_tenth))p > ~/NLP_Class/exe-1/Experiment$((i+1))/open-test
  cat $1 | sed $((i*one_tenth+1)),$(((i+1)*one_tenth))d > ~/NLP_Class/exe-1/Experiment$((i+1))/training
  cat ~/NLP_Class/exe-1/Experiment$((i+1))/training | shuf | sed $((one_tenth))q > ~/NLP_Class/exe-1/Experiment$((i+1))/closed-test
  
done

   
